## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(Rwplots)

## -----------------------------------------------------------------------------
data= system.file("extdata","Tracks.csv", package = "Rwplots")
head(read.csv(data))

## -----------------------------------------------------------------------------
data= system.file("extdata","Prec_data.csv", package = "Rwplots")
head(read.csv(data))

## -----------------------------------------------------------------------------
library(ncdf4)
data= system.file("extdata","Rainfall.nc", package = "Rwplots")
nc_val = nc_open(data)
nc_val

## -----------------------------------------------------------------------------
data = system.file("extdata","Rainfall.nc", package = "Rwplots")
precip_plot(data,"RAINFALL","LONGITUDE", "LATITUDE")

## -----------------------------------------------------------------------------
data= system.file("extdata","Tracks.csv", package = "Rwplots")
trackbyyear(data,"lat","lon", "kts", "name","year",2018,"India")

## -----------------------------------------------------------------------------
data= system.file("extdata","Tracks.csv", package = "Rwplots")
ts_tracks(data,"lon","lat","name","year")

## -----------------------------------------------------------------------------
data= system.file("extdata","Prec_data.csv", package = "Rwplots")
par(mar = rep(2, 4))
amd_plots(data,"time","Rainfall")

## -----------------------------------------------------------------------------
data= system.file("extdata","Prec_data.csv", package = "Rwplots")
matrix_plot(data,"time","Rainfall")

## -----------------------------------------------------------------------------
data= system.file("extdata","Prec_data.csv", package = "Rwplots")
d2m(data,"time","Rainfall")

## -----------------------------------------------------------------------------
data= system.file("extdata","Prec_data.csv", package = "Rwplots")
d2q(data,"time","Rainfall")

## -----------------------------------------------------------------------------
data= system.file("extdata","Prec_data.csv", package = "Rwplots")
d2a(data,"time","Rainfall")

